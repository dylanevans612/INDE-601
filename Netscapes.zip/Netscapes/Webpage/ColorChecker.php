<?php
$servername = "localhost";
$username = "root";
$password = "netscapes";
$dbname = "ColorApp";



$conn = new mysqli($servername, $username, $password, $dbname);


$query = "SELECT * FROM Colors;";

$result = $conn->query($query);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo $row["Color"] . ";";
    }
} else {
    echo "0 results";
}
$conn->close();

//selects the last 5 colours submitted to the database ready for ude by the person drawing.

?>
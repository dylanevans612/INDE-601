<?php
$servername = "localhost";
$username = "root";
$password = "Password";
$dbname = "ColorApp";

$Color = $_GET['color'];
$Image = $_GET['image'];

$conn = new mysqli($servername, $username, $password, $dbname);


$query = "INSERT INTO Colors (Color, IMG) VALUES ('" . $Color . "', '" . $Image . "');";

$result = $conn->query($query);

?>